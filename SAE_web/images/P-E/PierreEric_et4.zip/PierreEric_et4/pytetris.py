import modele
import vue
from time import *
class Controleur:
    def __init__(self, tetris):
        '''Controleur, ModeleTetris, VueTetris->None''' 
        self.__modele = tetris
        self.__vues = vue.VueTetris(self.__modele)
        self.__delai = self.__vues.get_delai()
        self.__fen = self.__vues.fenetre()
        self.__fen.bind("<Key-Left>",self.forme_a_gauche)
        self.__fen.bind("<Key-Right>",self.forme_a_droite)
        self.__fen.bind("<Key-Down>", self.forme_tombe)
        self.__fen.bind("<Key-Up>", self.forme_tourne)
        self.__vues.dessine_forme(self.__modele.get_coord_forme(), self.__modele.get_couleur_forme())
        self.joue()
        self.__fen.mainloop()
        
 
        
    def joue(self) :
        '''Controleur -> None
        boucle principale du jeu. Fait tomber une forme d’une ligne.'''
        if self.__vues.get_pause():
            self.pause()
        elif not self.__modele.fini():
            self.affichage()
            self.__vues.get_delai()
            self.__fen.after(self.__delai,self.joue)
        elif self.__modele.fini():

            self.__vues.recommencer()
            self.restart()
            
        else:
            lbl_message = self.__vues.Label(self.__fen, text="Game Over", fg="red", relief="raised")
            lbl_message.grid(row = 0, column = 0)
    
    def restart(self):
        '''Controleur->None'''
        if not self.__vues.get_pause():
            self.__fen.after(self.__delai,self.joue)
        else:
            self.__fen.after(self.__delai, self.restart)

            
    
    def pause (self):
        '''Controleur->None'''
        if not(self.__vues.get_pause()):
            self.__vues.dessine_forme_suivante(self.__modele.get_coords_suivante(), self.__modele.get_couleur_suivante())
            self.joue()
        else:
            self.__fen.after(self.__delai,self.pause)
            
            

    
    def affichage(self):
        '''Controleur->None'''
        touche = self.__modele.forme_tombe()
        self.__vues.dessine_terrain()
        score = self.__modele.get_score()
        self.__vues.dessine_forme(self.__modele.get_coord_forme(),self.__modele.get_couleur_forme())
        if touche==True:
            self.__delai=self.__vues.get_delai()
        self.__vues.mettre_a_jour_score(self.__modele.get_score())
        self.__vues.dessine_forme_suivante(self.__modele.get_coords_suivante(), self.__modele.get_couleur_suivante())
        self.__pause=self.__vues.get_pause()
    
    def forme_a_gauche(self,event):
        '''Controleur->None'''
        '''fais bouger la piece a gauche'''
        print('gauche')
        self.__modele.forme_a_gauche()
    
    def forme_a_droite(self,event):
        '''Controleur->None'''
        '''fais bouger la piece a gauche'''
        print('droite')
        self.__modele.forme_a_droite()
    
    def forme_tombe(self, event):
        '''Controleur->None'''
        self.__delai = 20
        
    def forme_tourne(self, event):
        '''Controleur->None'''
        self.__modele.forme_tourne()
        
if __name__ == "__main__" :
    # création du modèle
    tetris = modele.ModeleTetris()
    #vues = vue.VueTetris
    # création du contrôleur. c’est lui qui créé la boucle et lance la boucle d’écoute des évts
    ctrl = Controleur(tetris)