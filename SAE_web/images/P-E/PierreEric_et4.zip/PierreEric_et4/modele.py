import random
class ModeleTetris:
    def __init__ (self, ligne=20, colone=10):
        '''ModeleTetris, int, int->ModeleTetris'''
        self.__larg = colone
        self.__haut = ligne
        self.__base = 4
        self.__score = 0
        self.__terrain = []
        self.__suivante=Forme(self)
        self.__forme = self.__suivante
        self.__suivante = Forme(self)
        for i in range (self.__haut):
            ligne=[]
            for j in range (self.__larg):
                if i<self.__base:
                    ligne.append(-2)
                else:
                    ligne.append(-1)
            self.__terrain.append(ligne)
    
    
    
    '''def str(self):

        for i in range(len(self.__terrain)):
            print (self.__terrain[i])'''
    
    
    
    
    def get_largeur(self):
        '''ModeleTetris->int'''
        return self.__larg
    
    def get_hauteur(self):
        '''ModeleTetris->int'''
        return self.__haut
    
    def get_valeur(self, x,y):
        '''ModeleTetris, int, int->int'''
        return self.__terrain[x][y]
    
    def est_occupee(self, a,b):
        '''ModeleTetris, int, int->Bool'''
        #a = tuples[0]
        #b = tuples[1]
        '''if self.get_valeur(a,b)==-1 or self.get_valeur(a,b)==-2:
            return False
        return True'''
    
        if self.get_valeur(a,b)==-1 or self.get_valeur(a,b)==-2 :
            return False
        return True

    def fini(self):
        '''ModeleTetris->str'''
        for i in range (self.__larg):
            #if self.__terrain[self.__base][i]==0:
            if self.est_occupee(self.__base,i):
                return True
        return False
      
    
    
    
    def ajoute_forme(self):
        '''ModeleTetris->None'''
        for coo in self.__forme.get_coord():
            self.__terrain[coo[1]][coo[0]]=self.__forme.get_couleur()
    
    def forme_tombe(self):
        '''ModeleTetris->Bool'''
        if self.__forme.tombe():
            self.ajoute_forme()
            self.supprime_lignes_complete()
            self.__forme=self.__suivante
            self.__suivante=Forme(self)
            return True
        else:
            return False
        
    def get_couleur_forme(self):
        '''ModeleTetris->None'''
        return self.__forme.get_couleur()
    
    def get_coord_forme(self):
        return self.__forme.get_coord()
    
    def forme_a_gauche(self):
        '''ModeleTetris->None'''
        self.__forme.a_gauche()
        
    def forme_a_droite(self):
        '''ModeleTetris->None'''
        self.__forme.a_droite()
        
    def forme_tourne(self):
        '''ModeleTetris->None'''
        self.__forme.tourne()
        
    def est_ligne_complete(self, lig):
        '''ModeleTetris, int->Bool'''
        for i in range(self.__larg):
            if not(self.est_occupee(lig, i)):
                return False
        return True
    
    def supprime_ligne(self, lig):
        '''ModeleTetris, int->None'''
        new_modele=[]
        for i in range(lig):
            new_ligne=[]
            for j in range(self.get_largeur()):
                new_ligne.append(self.__terrain[i][j])
            new_modele.append(new_ligne)
        for i in range(lig):
            for j in range(self.get_largeur()):
                self.__terrain[i+1][j] = new_modele[i][j]
        for i in range(self.get_largeur()):
            self.__terrain[self.__base][i] = -1
    
    def supprime_lignes_complete(self):
        '''ModeleTetris->None'''
        for i in range(self.__base, self.get_hauteur()):
            if self.est_ligne_complete(i):
                self.supprime_ligne(i)
                self.__score+=1
    
    def get_score(self):
        '''ModeleTetris->int'''
        return self.__score
    
    def get_coords_suivante(self):
        '''ModeleTetris->[Int]'''
        return LES_FORME[self.__suivante.get_couleur()]
    
    def get_couleur_suivante(self):
        '''ModeleTetris->Str'''
        return self.__suivante.get_couleur()
    
    def recommence(self):
        '''ModeleTetris->None'''
        self.__score = 0
        self.__terrain = []
        self.__suivante=Forme(self)
        self.__forme = self.__suivante
        self.__suivante = Forme(self)
        for i in range (self.__haut):
            ligne=[]
            for j in range (self.__larg):
                if i<self.__base:
                    ligne.append(-2)
                else:
                    ligne.append(-1)
            self.__terrain.append(ligne)
    
            
LES_FORME = [[(-1,1),(-1,0),(0,0),(1,0)], [(-1,0), (0,0), (1,0), (1,1)], [(-1,1), (0,1), (0,0), (1,0)], [(-1,0), (0,0), (0, 1), (1,1)], [(-1,0), (0,0), (0,-1), (1,0)], [(0,0), (1,0), (1,1), (0,1)], [(0,-1),(0,0),(0,1), (0,2)],[(0, 0),(-1, 0),(1, 0),(-1, -1),(1, -1),(0, 1)],[(0, 0)], [(-1, 0), (1, 0)]]

class Forme:
    def __init__ (self, tetris):
        '''None, ModeleTetris -> Forme'''
        self.__modele = tetris
        ind = random.randint(0,len(LES_FORME)-1)
        self.__couleur = ind
        self.__forme = LES_FORME[ind]#[(-1,1),(-1,0),(0,0),(1,0)]
        self.__x0 = random.randint(2, self.__modele.get_largeur()-2)
        self.__y0 = 1
    
    
    
    def get_couleur(self):
        '''Forme->str'''
        return self.__couleur
     
    
    
    def get_coord(self):
        '''Forme->[int]'''
        new_coord=[]
        for i in range (len(self.__forme)):
            a,b = self.__forme[i]
            a += self.__x0
            b += self.__y0
            tuples = (a,b)
            new_coord.append(tuples)
        return new_coord

    def collision(self):
        '''Forme->Bool'''
        for coo in self.get_coord():
            if coo[1] +1 == self.__modele.get_hauteur():
                return True
            if self.__modele.est_occupee(coo[1]+1, coo[0]):
                return True
        return False
            

    def tombe(self):
        '''Forme->Bool'''
        if not(self.collision()):
            self.__y0+=1
            return False
        return True
    
    
    def position_valide(self):
        '''Forme->Bool'''
        coor = self.get_coord()
        for i in range (len(coor)):
            if not(coor[i][0] >=0 and coor[i][0]<self.__modele.get_largeur()):
                return False
            elif not( coor[i][1] >=0 or coor[i][1]<self.__modele.get_hauteur()):
                return False
            elif self.__modele.est_occupee(coor[i][1] ,coor[i][0] )==True:
                return False
        return True
 


            
    def a_gauche(self):
        '''Forme->None'''
        self.__x0-=1
        if not(self.position_valide()):
            self.__x0+=1
        
    def a_droite(self):
        '''Forme->None'''
        self.__x0+=1
        if not(self.position_valide()):
            self.__x0-=1
    
    def tourne (self):
        '''Forme->None'''
        new_forme=[]
        for i in range(len(self.__forme)):
            new_forme.append(self.__forme[i])
        for i in range(len(self.__forme)):
            (c,d)=new_forme[i]
            self.__forme[i]=(-d,c)
        if not(self.position_valide()):
            self.__forme=new_forme
    
    
    def get_coords_relatives(self):
        '''Forme->[Int]'''
        return LES_FORME[self.__couleur]
    
    