from tkinter import *
import modele
import pytetris
DIM=30
SUIVANT=6
COULEURS = ["red","yellow","green","cyan","orange","purple","pink", "white", "brown", "beige", "dark grey","black"]
class VueTetris:
    def __init__(self, modele):
        '''None, ModeleTetris -> None'''
        self.__delai=400
        self.__modele = modele
        self.__fenetre = Tk()
        self.__fenetre.title('Jeu')
        self.__can_terrain=Canvas(self.__fenetre,width=DIM*self.__modele.get_largeur(),height=DIM*self.__modele.get_hauteur())
        self.__can_terrain.grid(row = 0, column = 0)
        self.__les_cases=[]
        for i in range(self.__modele.get_hauteur()):
            l=[]
            for j in range(self.__modele.get_largeur()):
                l.append(self.__can_terrain.create_rectangle(j*DIM,i*DIM,(j+1)*DIM,DIM*(i+1) ,outline="grey",fill=COULEURS[self.__modele.get_valeur(i, j)]))
            self.__les_cases.append(l)
   

        self.__can_terrain.grid(row=0,column=0)
        self.__frame=Frame(self.__fenetre)
        self.__btn_quitter = Button(self.__frame ,text="Quit",bg="dark grey", command=self.__fenetre.destroy)
        self.__btn_quitter.pack()
        Label(self.__frame, text="Forme Suivante", fg="black", relief="raised")
        self.__can_fsuivante = Canvas(self.__frame, width = DIM*SUIVANT, height=SUIVANT*DIM)
        self.__les_suivants=[]
        for i in range(SUIVANT):
            l=[]
            for j in range(SUIVANT):
                l.append(self.__can_fsuivante.create_rectangle(i*DIM,j*DIM,(DIM+i)*DIM,DIM*(DIM+j) ,outline="grey",fill="black"))
            self.__les_suivants.append(l)
        self.__can_fsuivante.pack()
        self.__lbl_score = Label(self.__frame, text="Score = "+ str(self.__modele.get_score()), fg="red", relief="raised")
        self.__lbl_score.pack()
        self.__btn_start = Button(self.__frame ,text="Play",bg="dark grey", command=self.play)
        self.__btn_start.pack()
        self.__frame.grid(row=0,column=1)
        self.__pause=True
        
    def fenetre(self):
        '''VueTetris->Tk'''
        return self.__fenetre
    
    def dessine_case(self,i,j,coul):
        '''VueTetris, int, int, int->None'''
        self.__can_terrain.itemconfigure(self.__les_cases[i][j],fill=COULEURS[coul])
        


    def dessine_terrain(self):
        '''VueTetris->None'''
        for i in range(self.__modele.get_hauteur()):
            for j in range(self.__modele.get_largeur()):
                self.dessine_case(i,j, self.__modele.get_valeur(i,j))
                
    
    def dessine_forme(self, coord, couleur):
        '''VueTetris, tuple(int, int), int->None'''
        for coo in coord:
            self.dessine_case(coo[1],coo[0],couleur)
            
    def mettre_a_jour_score(self, val):
        '''VueTetris, int->None'''
        self.__lbl_score .configure(text="Score = "+ str(self.__modele.get_score()))
        self.__lbl_score.pack()
        self.__frame.grid(row=0,column=1)
        
    def dessine_case_suivante(self, x,y,coul):
        '''VueTetris, int, int, int->None'''
        self.__can_fsuivante.itemconfigure(self.__les_suivants[x][y],fill=COULEURS[coul])
    
    def nettoie_forme_suivante(self):
        '''VueTetris->None'''
        for x in range(SUIVANT):
            for y in range(SUIVANT):
                self.__can_fsuivante.itemconfigure(self.__les_suivants[x][y],fill='black')
    
    def dessine_forme_suivante(self, coord, coul):
        '''VueTetris, int, int->None'''
        self.nettoie_forme_suivante()
        for coo in coord:
            self.dessine_case_suivante(coo[1]+2,coo[0]+2,coul)
            
    def pause(self):
        '''Controleur->None'''
        self.__pause = True
        self.__btn_start.config(command=self.play, text="Play")
        print(self.__pause)
    
    def play (self):
        '''VueTetris->None'''
        self.__pause = False
        self.__btn_start.config(command=self.pause, text="Pause")
        print(self.__pause)
    
    def recommencer(self):
        '''VueTetris->None'''
        self.__pause=True
        if self.__modele.fini():
            self.__btn_start.config(command=self.restart, text="Restart")
            print('restart command activated')
    
    def restart(self):
        '''VueTetris->None'''
        self.__pause=False
        self.__btn_start.config(command=self.pause, text="Pause")
        self.nettoie_jeu()
        self.__modele.recommence()
        
        

    def nettoie_jeu(self):
        '''VueTetris->None'''
        haut = self.__modele.get_hauteur()
        for i in range(haut):
            self.__modele.supprime_ligne(i)

    

    def get_delai(self):
        '''VueTetris->Int'''
        return self.__delai
    
    def get_pause(self):
        '''VueTetris->Bool'''
        return self.__pause